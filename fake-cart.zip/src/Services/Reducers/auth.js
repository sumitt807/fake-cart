const initialState = {
    useruserdata: [],
}

const auth = (state = initialState, action) => {
    switch (action.type) {
        case 'USER_LOGIN':
            return {
                ...state,
                userdata: [
                    ...state.userdata, {
                        message: action.message,
                        id: action.id
                    }
                ]
            }
        case 'USER_LOGOUT':
            const auth = state.userdata.filter((todo) => todo.id !== action.id);
            return {
                ...state,
                userdata: auth
            }
        default:
            return state;
    }
}

export default auth;