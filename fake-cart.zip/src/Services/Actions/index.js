const ADD_TODO = 'ADD_TODO';
const addTodo = (message) => ({
    type: ADD_TODO,
    message,
    id: Math.random(),
})

const DELETE_TODO = 'DELETE_TODO';
const deleteTodo = (id) => ({
    type: DELETE_TODO,
    id,
})

const USER_LOGIN = 'USER_LOGIN';
const loginUser = (message) => ({
    type: USER_LOGIN,
    message,
    id: Math.random(),
})

const USER_LOGOUT = 'USER_LOGOUT';
const logoutUser = (id) => ({
    type: USER_LOGOUT,
    id,
})

export { addTodo, deleteTodo, loginUser, logoutUser };
