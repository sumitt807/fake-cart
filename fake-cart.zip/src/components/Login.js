import React from 'react';

const Login = () => {
    return <>
        <form>
            <input type="text" name='userName' />
            <input type="password" name='password' />
            <button onClick={ }>Login</button>
        </form>
    </>;
};

export default connect()(Login);
